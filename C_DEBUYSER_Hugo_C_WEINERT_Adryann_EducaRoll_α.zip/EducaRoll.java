import extensions.CSVFile;

class EducaRoll extends Program{

    // Constantes définies pour le fichier de questions, le nombre de tours, et le nombre de faces du dé
    final String FICHIER_QUESTION = "Questionnaire.csv";
    final int NB_TOURS = 10;
    final int NB_FACE_DE = 6;

    // Méthode pour afficher le menu et obtenir le mode de jeu (nombre de joueurs)
    int Menu(){
        println("____EducaRoll____");
        println();
        println("----Bienvenue sur EducaRoll !-----");
        println();
        println("/////////////////////// \n//// Mode de Jeu : //// \n///////////////////////");
        println("Selectionner le nombre de joueurs");
        int mode = 0;
        mode = readInt();
        return mode;
    }

    // Méthode pour simuler le lancer de dé et retourner un nombre aléatoire entre 1 et le nombre de faces du dé
    int randomDe(){
        return (int) (random()*NB_FACE_DE)+1;
    }

    // Méthode pour créer une nouvelle question en utilisant les informations fournies
    Question newQuestion(String type, String matiere, String question, String reponse, String justification){
        Question renvoie = new Question();
        renvoie.type = type;
        renvoie.matiere = matiere;
        renvoie.question = question;
        renvoie.reponse = reponse;
        renvoie.justification = justification;
        return renvoie;
    }

    // Méthode pour charger une question à partir d'un fichier CSV en fonction de la face du dé
    Question loadQuestion(String nomFichier, String faceDe){
        CSVFile QuestionCSV = loadCSV(nomFichier);
        int idx = (int)((random()*rowCount(QuestionCSV)));
        while(equals(getCell(QuestionCSV, idx, 0), faceDe)==false){
            idx = (int)((random()*rowCount(QuestionCSV)));
        }
        return newQuestion(getCell(QuestionCSV, idx, 0), getCell(QuestionCSV, idx, 1), getCell(QuestionCSV, idx, 2), getCell(QuestionCSV, idx, 3), getCell(QuestionCSV, idx, 4));
    }

    // Méthode pour vérifier la réponse donnée par le joueur à une question
    void checkAnswer(String reponse, Question question, Joueur joueur){
        println();
        if(equals(toUpperCase(reponse), toUpperCase(question.reponse))){
            joueur.NbBonneReponse = joueur.NbBonneReponse+1;
            println("Bonne réponse !");
            println();
        }
        else{
            println("Mauvaise réponse !\n" + question.justification);
            println();
        }
    }

    // Méthode pour demander au joueur s'il veut rejouer
    boolean rejouer(String c){
        if(equals(toUpperCase(c), "N")){
            return false;
        }
        return true;
    }

    // Méthode pour créer un nouveau joueur en demandant son nom
    Joueur newJoueur(){
        print("Entrez nom de Joueur : ");
        String nom = readString();
        println();
        Joueur renvoie = new Joueur();
        renvoie.nom = nom;
        return renvoie;
    }

     // Méthode pour gérer le tour de jeu d'un joueur
    void playTurn(Joueur joueur, int tourActuel){
        String face = "" + randomDe();
        println("Tours de " + joueur.nom + " N° " + tourActuel);
        print("face de dé : " + face + " ; ");
        Question selectedQuestion = loadQuestion(FICHIER_QUESTION, face);
        println("Question " + selectedQuestion.matiere);
        print(selectedQuestion.question + " ");
        checkAnswer(readString(), selectedQuestion, joueur);
    }

    // Méthode pour jouer le jeu avec un nombre donné de joueurs
    void PlayGame(int nbJoueur){
        Joueur[] joueurs = new Joueur [nbJoueur];
        for(int i = 0; i<nbJoueur;i++){
            joueurs[i] = newJoueur();
        }
        int numTours = 1;
        while(numTours<NB_TOURS+1){
            for(int i = 0; i<nbJoueur; i++){
                playTurn(joueurs[i], numTours);
            }
            numTours=numTours+1;
        }
        for(int i = 0; i<nbJoueur;i++){
            println(joueurs[i].nom + " a eu " + joueurs[i].NbBonneReponse + " bonnes réponses.");
        }
    }

    // Méthode principale pour exécuter le programme
    void algorithm(){
        int nbJoueur = Menu();
        PlayGame(nbJoueur);
    }
}