class Joueur{
    int NbBonneReponse;
    String nom;
}