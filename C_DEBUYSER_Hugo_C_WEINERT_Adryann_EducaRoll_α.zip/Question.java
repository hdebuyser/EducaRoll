class Question{
    String type;
    String matiere;
    String question;
    String reponse;
    String justification;
}